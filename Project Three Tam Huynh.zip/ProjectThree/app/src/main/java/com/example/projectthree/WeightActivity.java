package com.example.projectthree;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import java.util.ArrayList;

public class WeightActivity extends AppCompatActivity {

    DatabaseHelper db;
    EditText editTextDate, editTextWeight;
    GridView gridView;
    ArrayList<String> weightList;
    ArrayAdapter adapter;

    private static final int SMS_PERMISSION_REQUEST_CODE = 123;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weight);

        db = new DatabaseHelper(this);
        editTextDate = findViewById(R.id.editTextDate);
        editTextWeight = findViewById(R.id.editTextWeight);
        gridView = findViewById(R.id.gridView);

        weightList = new ArrayList<>();
        displayWeights();

        gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                // Handle item click if needed
            }
        });
    }

    public void onAddWeightClick(View view) {
        String date = editTextDate.getText().toString().trim();
        double weight = Double.parseDouble(editTextWeight.getText().toString().trim());
        boolean res = db.insertWeight(date, weight);
        if (res) {
            Toast.makeText(WeightActivity.this, "Weight Added", Toast.LENGTH_SHORT).show();
            displayWeights();
            // You could possibly check for a weight goal and notify via SMS here
        } else {
            Toast.makeText(WeightActivity.this, "Error Adding Weight", Toast.LENGTH_SHORT).show();
        }
    }

    public void onDeleteWeightClick(View view) {
        String date = editTextDate.getText().toString().trim();
        int deletedRows = db.deleteWeight(date);
        if (deletedRows > 0) {
            Toast.makeText(WeightActivity.this, "Weight Deleted", Toast.LENGTH_SHORT).show();
            displayWeights();
        } else {
            Toast.makeText(WeightActivity.this, "Error Deleting Weight", Toast.LENGTH_SHORT).show();
        }
    }

    public void onUpdateWeightClick(View view) {
        String date = editTextDate.getText().toString().trim();
        double weight = Double.parseDouble(editTextWeight.getText().toString().trim());
        boolean updated = db.updateWeight(date, weight);
        if (updated) {
            Toast.makeText(WeightActivity.this, "Weight Updated", Toast.LENGTH_SHORT).show();
            displayWeights();
            // You could possibly check for a weight goal and notify via SMS here
        } else {
            Toast.makeText(WeightActivity.this, "Error Updating Weight", Toast.LENGTH_SHORT).show();
        }
    }

    private void displayWeights() {
        Cursor cursor = db.getAllWeights();
        weightList.clear();
        while (cursor.moveToNext()) {
            weightList.add(cursor.getString(1) + " - " + cursor.getDouble(2) + " kg"); // Display as: "YYYY-MM-DD - 70.5 kg"
        }
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, weightList);
        gridView.setAdapter(adapter);
    }

    // Methods related to SMS permissions and sending

    private void requestSmsPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_REQUEST_CODE);
        } else {
            sendSmsNotification();
        }
    }

    @SuppressLint("MissingSuperCall")
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (requestCode == SMS_PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                sendSmsNotification();
            } else {
                Toast.makeText(this, "SMS permission denied. Notification feature disabled.", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void sendSmsNotification() {
        String phoneNumber = "YOUR_PHONE_NUMBER"; // Replace with the desired phone number or get it dynamically
        String message = "You have reached your weight goal!";

        try {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(phoneNumber, null, message, null, null);
            Toast.makeText(this, "Notification sent!", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, "Failed to send SMS.", Toast.LENGTH_SHORT).show();
        }
    }
}

